package org.ghotibeaun.json.parser;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.ghotibeaun.json.JSONArray;
import org.ghotibeaun.json.JSONObject;
import org.ghotibeaun.json.JSONValue;
import org.ghotibeaun.json.JSONValueType;

public class TestJSONObject implements JSONObject {

    public TestJSONObject() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public void put(String key, JSONValue<?> value) {
        // TODO Auto-generated method stub

    }

    @Override
    public void put(String key, Object value) {
        // TODO Auto-generated method stub

    }

    @Override
    public void putAll(Map<String, JSONValue<?>> map) {
        // TODO Auto-generated method stub

    }

    @Override
    public void putAllRaw(Map<String, Object> map) {
        // TODO Auto-generated method stub

    }

    @Override
    public void clear() {
        // TODO Auto-generated method stub

    }

    @Override
    public int size() {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public Collection<JSONValue<?>> values() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Iterable<String> keys() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public JSONValue<?> get(String key) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<String, Object> getMap() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Set<Entry<String, JSONValue<?>>> elements() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String[] names() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean containsKey(String key) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public JSONValue<?> remove(String key) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String toJSONString() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void put(String key, Number n) {
        // TODO Auto-generated method stub

    }

    @Override
    public void put(String key, String s) {
        // TODO Auto-generated method stub

    }

    @Override
    public void put(String key, boolean b) {
        // TODO Auto-generated method stub

    }

    @Override
    public void put(String key, JSONArray a) {
        // TODO Auto-generated method stub

    }

    @Override
    public void put(String key, JSONObject o) {
        // TODO Auto-generated method stub

    }

    @Override
    public void putNull(String key) {
        // TODO Auto-generated method stub

    }

    @Override
    public JSONObject getJSONObject(String key) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public JSONArray getJSONArray(String key) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Number getNumber(String key) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getLong(String key) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int getInt(String key) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public boolean getBoolean(String key) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public JSONValueType getValueType(String key) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getString(String key) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String prettyPrint() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String prettyPrint(int indent) {
        // TODO Auto-generated method stub
        return null;
    }

}
