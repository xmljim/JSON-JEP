/*
 * $Header: $
 * $Id$
 *
 * Copyright (c) 2014, Flatirons Solutions. All Rights Reserved.
 * This code may not be used without the express written permission
 * of the copyright holder, Flatirons Solutions.
 */
/**
 * @author Jim Earley (xml.jim@gmail.com)
 *
 */
package org.ghotibeaun.json.parser.jep.eventprovider;