package org.ghotibeaun.json.parser.jep;

public interface Configurable {
    void setParserSettings(ParserSettings settings);

    ParserSettings getParserSettings();
}
