package org.ghotibeaun.json.exception;

@SuppressWarnings("serial")
public class JSONSerializationException extends JSONException {

    public JSONSerializationException() {
        // TODO Auto-generated constructor stub
    }

    public JSONSerializationException(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public JSONSerializationException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public JSONSerializationException(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

}
