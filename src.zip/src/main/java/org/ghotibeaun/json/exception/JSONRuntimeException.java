package org.ghotibeaun.json.exception;

public class JSONRuntimeException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public JSONRuntimeException() {
        // TODO Auto-generated constructor stub
    }

    public JSONRuntimeException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public JSONRuntimeException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

    public JSONRuntimeException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

}
