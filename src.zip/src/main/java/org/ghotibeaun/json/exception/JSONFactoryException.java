package org.ghotibeaun.json.exception;

public class JSONFactoryException extends JSONRuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public JSONFactoryException() {
        // TODO Auto-generated constructor stub
    }

    public JSONFactoryException(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public JSONFactoryException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public JSONFactoryException(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

}
