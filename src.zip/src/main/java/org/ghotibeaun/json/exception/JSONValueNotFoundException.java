package org.ghotibeaun.json.exception;

public class JSONValueNotFoundException extends JSONException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public JSONValueNotFoundException() {
        // TODO Auto-generated constructor stub
    }

    public JSONValueNotFoundException(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public JSONValueNotFoundException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public JSONValueNotFoundException(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

}
