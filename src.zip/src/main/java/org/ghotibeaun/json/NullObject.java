package org.ghotibeaun.json;

public class NullObject {

    public NullObject() {
        // no-op
    }

    @Override
    public String toString() {
        return "null";
    }

}
