/*
 *
 * Copyright (c) 2017, Jim Earley (xml.jim@gmail.com
 */
/**
 * @author Jim Earley
 * Integration of JSON Path for parsed JSON.
 */
package org.ghotibeaun.json.jsonpath;