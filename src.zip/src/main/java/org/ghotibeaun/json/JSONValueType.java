package org.ghotibeaun.json;

public enum JSONValueType {
    BOOLEAN, STRING, NUMBER, ARRAY, OBJECT, DATE, NULL
}
